import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Assiment1017 {
	public static void main(String args[]) {
		String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Hao%20Huang";
		URL getUrl;
		try {
			getUrl = new URL(url);
			HttpURLConnection connection = (HttpURLConnection) getUrl
					.openConnection();
			File assiment = new File(
					"C:/Users/Administrator/Desktop/Assiment.txt");
			connection.connect();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					connection.getInputStream(), "UTF-8"));
			PrintStream read = new PrintStream(assiment);
			Document doc = Jsoup.connect(url).get();
			String str = doc
					.getElementsByAttributeValue("class",
							"details col-md-10 col-sm-9 col-xs-7").get(0)
					.text();
			String title = doc.title();
			String name = doc
					.getElementsByAttributeValue("class",
							"logo col-md-4 col-sm-4").get(0).text();
			String job = doc
					.getElementsByAttributeValue("class",
							"logo col-md-4 col-sm-4").get(0).text();
			String resum = doc
					.getElementsByAttributeValue("class",
							"details col-md-12 col-sm-12 col-xs-12").get(0)
					.text();
			Elements el = doc.getElementsByTag("p");
			String p = el.get(0).text();
			read.println("������" + name);

			String numPTag[] = p.split(" ");

			read.println("ְ��:" + numPTag[0] + " " + numPTag[2]);
			String str110 = "\\d{3}-\\d{8}";
			String str111 = "\\w+@\\w+(\\.\\w+)+";
			Pattern pattern = Pattern.compile(str110);
			Matcher m0 = pattern.matcher(str);
			if (m0.find()) {
				read.println(name + "�ĵ绰��" + m0.group(0));
			}
			pattern = Pattern.compile(str111);
			m0 = pattern.matcher(str);
			if (m0.find()) {
				read.println(name + "�����䣺" + m0.group(0));
			}
			String str10[] = resum.split(" ");
			for (String str11 : str10) {
				read.println(str11);
			}
			/*
			 * read.println(name+"�ļ�����"+doc
			 * .getElementsByAttributeValue("class",
			 * "details col-md-12 col-sm-12 col-xs-12").get(0) .text());
			 */
			read.close();
			// }

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
